# A2M2 Frontend

A next-generation DEX interface featuring a dual UI mode (Basic and Advanced) built with Next.js, TypeScript, and Tailwind CSS.

## Prerequisites

- Node.js 18+ (LTS)
- Bun 1.0.0+

## Getting Started

1. Clone the repository:
```bash
git clone <repository-url>
cd quantum-amm
```

2. Install dependencies:
```bash
bun install
```

3. Run the development server:
```bash
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Available Scripts

- `bun dev` - Start development server
- `bun build` - Build production bundle
- `bun start` - Start production server
- `bun lint` - Run ESLint
- `bun format` - Format code with Prettier
- `bun test` - Run tests
- `bun test:watch` - Run tests in watch mode

## Project Structure

```
src/
  app/                    # Next.js app router pages
  components/
    basic/               # Basic mode components
    advanced/            # Advanced mode components
    shared/             # Shared components
    ui/                 # Base UI components
  hooks/                # Custom hooks
  context/              # React context providers
  services/             # API/WebSocket services
  utils/                # Utility functions
  types/                # TypeScript types/interfaces
  styles/               # Global styles
  constants/            # Constants and configurations
  tests/                # Test utilities and mocks
```

## Contributing

1. Create a feature branch
2. Make your changes
3. Run tests and linting
4. Submit a pull request

## License

[MIT](LICENSE)
