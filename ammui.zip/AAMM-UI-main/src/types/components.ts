import { ReactNode, ButtonHTMLAttributes, InputHTMLAttributes } from 'react';

export type Size = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
export type Variant = 'primary' | 'secondary' | 'tertiary' | 'ghost' | 'link';
export type Status = 'idle' | 'loading' | 'success' | 'error';

export interface BaseProps {
  className?: string;
  children?: ReactNode;
}

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement>, BaseProps {
  variant?: Variant;
  size?: Size;
  status?: Status;
  isLoading?: boolean;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
}

export interface InputProps extends InputHTMLAttributes<HTMLInputElement>, BaseProps {
  label?: string;
  error?: string;
  hint?: string;
  leftElement?: ReactNode;
  rightElement?: ReactNode;
  isLoading?: boolean;
}

export interface ModalProps extends BaseProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  description?: string;
  size?: Size;
}

export interface DropdownProps extends BaseProps {
  trigger: ReactNode;
  items: Array<{
    label: string;
    value: string;
    icon?: ReactNode;
    disabled?: boolean;
  }>;
  value?: string;
  onChange?: (value: string) => void;
  placement?: 'top' | 'bottom' | 'left' | 'right';
}

export interface CardProps extends BaseProps {
  title?: string;
  subtitle?: string;
  footer?: ReactNode;
  isLoading?: boolean;
  variant?: 'elevated' | 'outlined' | 'filled';
}

export interface LoadingProps extends BaseProps {
  size?: Size;
  variant?: 'spinner' | 'dots' | 'pulse';
}

export interface NotificationProps extends BaseProps {
  title: string;
  description?: string;
  status?: Status;
  duration?: number;
  isClosable?: boolean;
  onClose?: () => void;
}

export interface ToggleProps extends BaseProps {
  isChecked?: boolean;
  onChange?: (isChecked: boolean) => void;
  size?: Size;
  disabled?: boolean;
}

export interface ProgressProps extends BaseProps {
  value: number;
  max?: number;
  size?: Size;
  variant?: 'line' | 'circle';
  showLabel?: boolean;
}

export interface ChartProps extends BaseProps {
  data: Array<{ x: number | string; y: number }>;
  type?: 'line' | 'bar' | 'area';
  height?: number;
  width?: number;
  showAxes?: boolean;
  showGrid?: boolean;
  showTooltip?: boolean;
}
