export type NetworkType = 'mainnet' | 'testnet';

export interface Token {
  address: string;
  symbol: string;
  name: string;
  decimals: number;
  chainId: number;
  logoURI: string;
}

export interface TokenAmount {
  token: Token;
  amount: string;
}

export interface SwapRoute {
  inputToken: Token;
  outputToken: Token;
  path: Token[];
  priceImpact: string;
  executionPrice: string;
  minimumReceived: string;
  maximumSent: string;
}

export interface TransactionStatus {
  status: 'pending' | 'success' | 'failed';
  hash: string;
  timestamp: number;
  errorMessage?: string;
}

export interface WalletInfo {
  address: string;
  chainId: number;
  isConnected: boolean;
  balance: string;
}

export type UIMode = 'basic' | 'advanced';
