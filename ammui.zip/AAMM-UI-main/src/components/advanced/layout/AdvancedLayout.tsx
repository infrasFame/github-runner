'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useAppContext } from '@/context/AppContext';
import {
  ChartBarIcon,
  BookOpenIcon,
  ClockIcon,
  Cog6ToothIcon,
  ArrowsPointingInIcon,
  ArrowsPointingOutIcon,
  MoonIcon,
  SunIcon,
  ChevronRightIcon,
  Bars3Icon,
} from '@heroicons/react/24/outline';
import { OrderBook } from '../panels/OrderBook';
import { TransactionHistory } from '../panels/TransactionHistory';
import { Dropdown } from '@/components/ui/Dropdown';
import { useRouter } from 'next/navigation';

interface AdvancedLayoutProps {
  children: React.ReactNode;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const panelVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.3 },
  },
};

const mobileMenuVariants = {
  closed: { opacity: 0, y: 100 },
  open: { opacity: 1, y: 0 },
};

export function AdvancedLayout({ children }: AdvancedLayoutProps) {
  const { state, dispatch } = useAppContext();
  const [isChartExpanded, setIsChartExpanded] = useState(false);
  const [activePanel, setActivePanel] = useState<'charts' | 'orders' | 'history' | 'settings'>(
    'charts'
  );
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const router = useRouter();

  const dropdownItems = [
    {
      label: state.isDarkMode ? 'Light Mode' : 'Dark Mode',
      value: 'theme',
      icon: state.isDarkMode ? <SunIcon className="h-5 w-5" /> : <MoonIcon className="h-5 w-5" />,
    },
    {
      label: 'Switch to Basic',
      value: 'mode',
      icon: <ChevronRightIcon className="h-5 w-5" />,
    },
  ];

  const handleDropdownChange = (value: string) => {
    if (value === 'theme') {
      dispatch({ type: 'SET_DARK_MODE', payload: !state.isDarkMode });
    } else if (value === 'mode') {
      router.push('/basic');
    }
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className={`flex min-h-screen flex-col ${
        state.isDarkMode
          ? 'bg-gradient-to-b from-gray-900 to-gray-950'
          : 'bg-gradient-to-b from-gray-50 to-white'
      }`}
    >
      {/* Header */}
      <motion.header
        variants={panelVariants}
        className={`sticky top-0 z-50 border-b backdrop-blur-lg ${
          state.isDarkMode ? 'border-gray-800/50 bg-gray-900/80' : 'border-gray-200/50 bg-white/80'
        }`}
      >
        <nav className="mx-auto flex max-w-7xl items-center justify-between p-4">
          {/* Left section */}
          <motion.h1
            whileHover={{ scale: 1.02 }}
            className="text-lg font-bold text-blue-500 sm:text-xl"
          >
            A2M2
          </motion.h1>

          {/* Desktop Navigation */}
          <div className="hidden items-center gap-3 sm:flex sm:gap-4">
            {/* Settings Dropdown */}
            <Dropdown
              trigger={
                <div className="flex items-center gap-2">
                  <Cog6ToothIcon
                    className={`h-5 w-5 ${state.isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}
                  />
                  <span
                    className={`text-sm ${state.isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}
                  >
                    Settings
                  </span>
                </div>
              }
              items={dropdownItems}
              onChange={handleDropdownChange}
              placement="bottom"
            />

            {/* Sync Wallet button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="rounded-full bg-blue-500 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-600"
            >
              Sync Wallet
            </motion.button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="rounded-lg p-2 sm:hidden"
          >
            <Bars3Icon
              className={`h-6 w-6 ${state.isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}
            />
          </button>
        </nav>

        {/* Mobile Menu */}
        <motion.div
          initial="closed"
          animate={isMobileMenuOpen ? 'open' : 'closed'}
          variants={mobileMenuVariants}
          className={`border-t sm:hidden ${
            state.isDarkMode ? 'border-gray-800/50' : 'border-gray-200/50'
          }`}
        >
          {isMobileMenuOpen && (
            <div className="space-y-2 p-4">
              {/* Mobile Settings */}
              {dropdownItems.map((item) => (
                <button
                  key={item.value}
                  onClick={() => handleDropdownChange(item.value)}
                  className={`flex w-full items-center gap-2 rounded-lg px-4 py-2 text-sm ${
                    state.isDarkMode
                      ? 'text-gray-300 hover:bg-gray-800'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <span className={state.isDarkMode ? 'text-gray-400' : 'text-gray-500'}>
                    {item.icon}
                  </span>
                  {item.label}
                </button>
              ))}

              {/* Mobile Sync Wallet button */}
              <motion.button
                whileTap={{ scale: 0.98 }}
                className="w-full rounded-lg bg-blue-500 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-600"
              >
                Sync Wallet
              </motion.button>
            </div>
          )}
        </motion.div>
      </motion.header>

      {/* Main content */}
      <motion.main
        variants={panelVariants}
        className="relative flex flex-1 gap-4 overflow-hidden p-4"
      >
        {/* Left panel - Swap Interface */}
        <motion.div
          variants={panelVariants}
          className={`flex w-full flex-col gap-4 sm:w-[400px] ${
            state.isDarkMode ? 'text-white' : 'text-gray-900'
          }`}
        >
          {children}
        </motion.div>

        {/* Right panel - Charts, Order Book, History */}
        <motion.div
          variants={panelVariants}
          className={`hidden flex-1 flex-col gap-4 rounded-xl border backdrop-blur-lg sm:flex ${
            state.isDarkMode
              ? 'border-gray-800/50 bg-gray-900/50'
              : 'border-gray-200/50 bg-white/50'
          }`}
        >
          {/* Panel Header */}
          <div className="flex items-center justify-between border-b p-4">
            <div className="flex gap-4">
              <button
                onClick={() => setActivePanel('charts')}
                className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm transition-colors ${
                  activePanel === 'charts'
                    ? 'bg-blue-500 text-white'
                    : state.isDarkMode
                      ? 'text-gray-400 hover:bg-gray-800'
                      : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <ChartBarIcon className="h-4 w-4" />
                Charts
              </button>
              <button
                onClick={() => setActivePanel('orders')}
                className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm transition-colors ${
                  activePanel === 'orders'
                    ? 'bg-blue-500 text-white'
                    : state.isDarkMode
                      ? 'text-gray-400 hover:bg-gray-800'
                      : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <BookOpenIcon className="h-4 w-4" />
                Order Book
              </button>
              <button
                onClick={() => setActivePanel('history')}
                className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm transition-colors ${
                  activePanel === 'history'
                    ? 'bg-blue-500 text-white'
                    : state.isDarkMode
                      ? 'text-gray-400 hover:bg-gray-800'
                      : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <ClockIcon className="h-4 w-4" />
                History
              </button>
            </div>
            <button
              onClick={() => setIsChartExpanded(!isChartExpanded)}
              className={`rounded-lg p-1.5 transition-colors ${
                state.isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'
              }`}
            >
              {isChartExpanded ? (
                <ArrowsPointingInIcon className="h-5 w-5" />
              ) : (
                <ArrowsPointingOutIcon className="h-5 w-5" />
              )}
            </button>
          </div>

          {/* Panel Content */}
          <div className="flex-1 p-4">
            {activePanel === 'charts' && (
              <div className="h-full rounded-lg border bg-white/50 p-4 dark:bg-gray-800/50">
                <div className="text-sm">Price Chart Coming Soon</div>
              </div>
            )}
            {activePanel === 'orders' && <OrderBook />}
            {activePanel === 'history' && <TransactionHistory />}
          </div>
        </motion.div>
      </motion.main>
    </motion.div>
  );
}
