'use client';

import { useState } from 'react';
import { useAppContext } from '@/context/AppContext';
import {
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon,
  ArrowUpRightIcon,
} from '@heroicons/react/24/outline';

interface Transaction {
  hash: string;
  type: 'buy' | 'sell';
  tokenA: string;
  tokenB: string;
  amountA: string;
  amountB: string;
  status: 'completed' | 'pending' | 'failed';
  timestamp: number;
}

// Demo data - replace with real data from API
const DEMO_TRANSACTIONS: Transaction[] = [
  {
    hash: '0x1234...5678',
    type: 'buy',
    tokenA: 'ETH',
    tokenB: 'USDC',
    amountA: '1.5',
    amountB: '3,456.75',
    status: 'completed',
    timestamp: Date.now() - 1000 * 60 * 2, // 2 minutes ago
  },
  {
    hash: '0x8765...4321',
    type: 'sell',
    tokenA: 'ETH',
    tokenB: 'USDC',
    amountA: '0.5',
    amountB: '1,152.25',
    status: 'pending',
    timestamp: Date.now() - 1000 * 60 * 5, // 5 minutes ago
  },
  {
    hash: '0xabcd...efgh',
    type: 'buy',
    tokenA: 'ETH',
    tokenB: 'USDC',
    amountA: '2.0',
    amountB: '4,608.00',
    status: 'failed',
    timestamp: Date.now() - 1000 * 60 * 10, // 10 minutes ago
  },
  {
    hash: '0x9876...5432',
    type: 'sell',
    tokenA: 'ETH',
    tokenB: 'USDC',
    amountA: '1.0',
    amountB: '2,304.50',
    status: 'completed',
    timestamp: Date.now() - 1000 * 60 * 15, // 15 minutes ago
  },
  {
    hash: '0xijkl...mnop',
    type: 'buy',
    tokenA: 'ETH',
    tokenB: 'USDC',
    amountA: '0.75',
    amountB: '1,728.37',
    status: 'completed',
    timestamp: Date.now() - 1000 * 60 * 20, // 20 minutes ago
  },
];

const statusConfig = {
  completed: { icon: CheckCircleIcon, className: 'text-green-500' },
  pending: { icon: ClockIcon, className: 'text-blue-500' },
  failed: { icon: XCircleIcon, className: 'text-red-500' },
};

function formatTimeAgo(timestamp: number): string {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export function TransactionHistory() {
  const { state } = useAppContext();
  const [filter, setFilter] = useState<'all' | 'buy' | 'sell'>('all');

  const filteredTransactions = DEMO_TRANSACTIONS.filter(
    (tx) => filter === 'all' || tx.type === filter
  );

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-gray-600 dark:text-gray-400">Filter:</span>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as 'all' | 'buy' | 'sell')}
            className={`rounded-lg border px-2 py-1 text-xs ${
              state.isDarkMode
                ? 'border-gray-700 bg-gray-800 text-gray-300'
                : 'border-gray-300 bg-white text-gray-900'
            }`}
          >
            <option value="all">All</option>
            <option value="buy">Buy</option>
            <option value="sell">Sell</option>
          </select>
        </div>
        <div className="text-xs font-medium text-gray-600 dark:text-gray-400">
          Last 24h Transactions
        </div>
      </div>

      {/* Transactions List */}
      <div className="flex-1 overflow-hidden rounded-lg border dark:border-gray-700">
        {/* Column Headers */}
        <div
          className={`grid grid-cols-6 gap-4 border-b px-4 py-2 text-xs font-medium ${
            state.isDarkMode ? 'border-gray-700 text-gray-400' : 'border-gray-200 text-gray-600'
          }`}
        >
          <div>Type</div>
          <div>Amount</div>
          <div>Price</div>
          <div>Total</div>
          <div>Status</div>
          <div>Time</div>
        </div>

        {/* Transactions */}
        <div className="divide-y dark:divide-gray-700">
          {filteredTransactions.map((tx, index) => {
            const StatusIcon = statusConfig[tx.status].icon;
            return (
              <div
                key={tx.hash}
                className={`grid grid-cols-6 gap-4 px-4 py-3 text-xs hover:bg-gray-50 dark:hover:bg-gray-800/50 ${
                  tx.status === 'pending' ? 'animate-pulse' : ''
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <span
                    className={`font-medium ${
                      tx.type === 'buy' ? 'text-green-500' : 'text-red-500'
                    }`}
                  >
                    {tx.type.toUpperCase()}
                  </span>
                </div>
                <div className="font-medium text-gray-900 dark:text-gray-100">
                  {tx.amountA} {tx.tokenA}
                </div>
                <div className="text-gray-600 dark:text-gray-400">
                  {(Number(tx.amountB) / Number(tx.amountA)).toFixed(2)} {tx.tokenB}
                </div>
                <div className="font-medium text-gray-900 dark:text-gray-100">
                  {tx.amountB} {tx.tokenB}
                </div>
                <div className="flex items-center gap-1">
                  <StatusIcon className={`h-4 w-4 ${statusConfig[tx.status].className}`} />
                  <span
                    className={`capitalize ${
                      tx.status === 'completed'
                        ? 'text-green-500'
                        : tx.status === 'pending'
                          ? 'text-blue-500'
                          : 'text-red-500'
                    }`}
                  >
                    {tx.status}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600 dark:text-gray-400">
                    {formatTimeAgo(tx.timestamp)}
                  </span>
                  <a
                    href={`https://etherscan.io/tx/${tx.hash}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:text-blue-600"
                  >
                    <ArrowUpRightIcon className="h-4 w-4" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer Stats */}
      <div className="mt-2 grid grid-cols-3 gap-4 text-center text-xs">
        <div>
          <span className="text-gray-600 dark:text-gray-400">Total Trades: </span>
          <span className="font-medium text-gray-900 dark:text-gray-100">152</span>
        </div>
        <div>
          <span className="text-gray-600 dark:text-gray-400">Success Rate: </span>
          <span className="font-medium text-green-500">98.7%</span>
        </div>
        <div>
          <span className="text-gray-600 dark:text-gray-400">Avg. Execution: </span>
          <span className="font-medium text-gray-900 dark:text-gray-100">2.3s</span>
        </div>
      </div>
    </div>
  );
}
