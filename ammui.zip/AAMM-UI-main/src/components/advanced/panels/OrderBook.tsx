'use client';

import { useState } from 'react';
import { useAppContext } from '@/context/AppContext';

interface Order {
  price: string;
  size: string;
  total: string;
  depth: number;
}

// Demo data - replace with real data from API
const DEMO_ASKS: Order[] = [
  { price: '2305.50', size: '0.425', total: '979.83', depth: 20 },
  { price: '2305.25', size: '1.230', total: '2835.45', depth: 40 },
  { price: '2305.00', size: '0.890', total: '2051.45', depth: 60 },
  { price: '2304.75', size: '2.150', total: '4955.21', depth: 80 },
  { price: '2304.50', size: '1.750', total: '4032.87', depth: 100 },
].reverse();

const DEMO_BIDS: Order[] = [
  { price: '2304.25', size: '1.890', total: '4355.03', depth: 100 },
  { price: '2304.00', size: '1.230', total: '2833.92', depth: 80 },
  { price: '2303.75', size: '0.670', total: '1543.51', depth: 60 },
  { price: '2303.50', size: '0.980', total: '2257.43', depth: 40 },
  { price: '2303.25', size: '0.450', total: '1036.46', depth: 20 },
];

export function OrderBook() {
  const { state } = useAppContext();
  const [grouping, setGrouping] = useState(0.25);

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-gray-600 dark:text-gray-400">Group:</span>
          <select
            value={grouping}
            onChange={(e) => setGrouping(Number(e.target.value))}
            className={`rounded-lg border px-2 py-1 text-xs ${
              state.isDarkMode
                ? 'border-gray-700 bg-gray-800 text-gray-300'
                : 'border-gray-300 bg-white text-gray-900'
            }`}
          >
            <option value={0.25}>0.25</option>
            <option value={0.5}>0.50</option>
            <option value={1}>1.00</option>
          </select>
        </div>
        <div className="text-xs font-medium text-gray-600 dark:text-gray-400">
          Spread: 0.25 (0.01%)
        </div>
      </div>

      {/* Order Book Table */}
      <div className="flex-1 overflow-hidden rounded-lg border dark:border-gray-700">
        {/* Column Headers */}
        <div
          className={`grid grid-cols-3 gap-4 border-b px-4 py-2 text-xs font-medium ${
            state.isDarkMode ? 'border-gray-700 text-gray-400' : 'border-gray-200 text-gray-600'
          }`}
        >
          <div>Price</div>
          <div className="text-right">Size</div>
          <div className="text-right">Total</div>
        </div>

        {/* Asks */}
        <div className="relative">
          {DEMO_ASKS.map((order, index) => (
            <div key={`ask-${index}`} className="relative grid grid-cols-3 gap-4 px-4 py-1 text-xs">
              <div
                className="absolute inset-0 bg-red-500/10"
                style={{ width: `${order.depth}%` }}
              />
              <div className="relative font-medium text-red-500">{order.price}</div>
              <div className="relative text-right font-medium text-gray-900 dark:text-gray-100">
                {order.size}
              </div>
              <div className="relative text-right text-gray-600 dark:text-gray-400">
                {order.total}
              </div>
            </div>
          ))}
        </div>

        {/* Current Price */}
        <div
          className={`border-y px-4 py-2 text-center text-sm font-semibold ${
            state.isDarkMode
              ? 'border-gray-700 bg-gray-800/50 text-gray-100'
              : 'border-gray-200 bg-gray-50 text-gray-900'
          }`}
        >
          2304.50 USDC
        </div>

        {/* Bids */}
        <div className="relative">
          {DEMO_BIDS.map((order, index) => (
            <div key={`bid-${index}`} className="relative grid grid-cols-3 gap-4 px-4 py-1 text-xs">
              <div
                className="absolute inset-0 bg-green-500/10"
                style={{ width: `${order.depth}%` }}
              />
              <div className="relative font-medium text-green-500">{order.price}</div>
              <div className="relative text-right font-medium text-gray-900 dark:text-gray-100">
                {order.size}
              </div>
              <div className="relative text-right text-gray-600 dark:text-gray-400">
                {order.total}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer Stats */}
      <div className="mt-2 grid grid-cols-2 gap-4 text-center text-xs">
        <div>
          <span className="text-gray-600 dark:text-gray-400">24h Volume: </span>
          <span className="font-medium text-gray-900 dark:text-gray-100">$124.5M</span>
        </div>
        <div>
          <span className="text-gray-600 dark:text-gray-400">24h Trades: </span>
          <span className="font-medium text-gray-900 dark:text-gray-100">15,234</span>
        </div>
      </div>
    </div>
  );
}
