'use client';

import { CardProps } from '@/types/components';
import { cn } from '@/utils/styles';

const variantClasses = {
  elevated: 'bg-white shadow-md dark:bg-gray-800 hover:shadow-lg transition-shadow duration-200',
  outlined: 'border border-gray-200 dark:border-gray-700 bg-transparent',
  filled: 'bg-gray-50 dark:bg-gray-900',
};

export function Card({
  className,
  title,
  subtitle,
  footer,
  variant = 'elevated',
  isLoading,
  children,
}: CardProps) {
  return (
    <div className={cn('overflow-hidden rounded-lg', variantClasses[variant], className)}>
      {isLoading ? (
        <div className="p-4">
          <div className="space-y-3">
            <div className="h-4 w-2/3 animate-pulse rounded bg-gray-200 dark:bg-gray-700" />
            <div className="h-4 w-full animate-pulse rounded bg-gray-200 dark:bg-gray-700" />
            <div className="h-4 w-4/5 animate-pulse rounded bg-gray-200 dark:bg-gray-700" />
          </div>
        </div>
      ) : (
        <>
          {(title || subtitle) && (
            <div className="border-b border-gray-200 px-4 py-5 sm:px-6 dark:border-gray-700">
              {title && (
                <h3 className="text-lg font-medium leading-6 text-gray-900 dark:text-white">
                  {title}
                </h3>
              )}
              {subtitle && (
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{subtitle}</p>
              )}
            </div>
          )}
          <div className="px-4 py-5 sm:p-6">{children}</div>
          {footer && (
            <div className="border-t border-gray-200 px-4 py-4 sm:px-6 dark:border-gray-700">
              {footer}
            </div>
          )}
        </>
      )}
    </div>
  );
}
