'use client';

import { LoadingProps } from '@/types/components';
import { cn } from '@/utils/styles';

const sizeClasses = {
  xs: 'h-3 w-3',
  sm: 'h-4 w-4',
  md: 'h-6 w-6',
  lg: 'h-8 w-8',
  xl: 'h-10 w-10',
};

const SpinnerLoading = ({ size = 'md', className }: LoadingProps) => (
  <div
    className={cn(
      'animate-spin rounded-full border-2 border-current border-t-transparent text-gray-900 dark:text-white',
      sizeClasses[size],
      className
    )}
  />
);

const DotsLoading = ({ size = 'md', className }: LoadingProps) => (
  <div className={cn('flex space-x-1', className)}>
    {[0, 1, 2].map((i) => (
      <div
        key={i}
        className={cn(
          'animate-pulse rounded-full bg-current text-gray-900 dark:text-white',
          sizeClasses[size]
        )}
        style={{
          animationDelay: `${i * 150}ms`,
        }}
      />
    ))}
  </div>
);

const PulseLoading = ({ size = 'md', className }: LoadingProps) => (
  <div
    className={cn(
      'animate-pulse rounded-full bg-current text-gray-900 dark:text-white',
      sizeClasses[size],
      className
    )}
  />
);

export function Loading({ variant = 'spinner', ...props }: LoadingProps) {
  switch (variant) {
    case 'dots':
      return <DotsLoading {...props} />;
    case 'pulse':
      return <PulseLoading {...props} />;
    default:
      return <SpinnerLoading {...props} />;
  }
}
