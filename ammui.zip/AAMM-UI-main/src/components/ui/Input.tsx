'use client';

import { forwardRef } from 'react';
import { InputProps } from '@/types/components';
import { cn } from '@/utils/styles';

export const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      className,
      type = 'text',
      label,
      error,
      hint,
      leftElement,
      rightElement,
      isLoading,
      disabled,
      ...props
    },
    ref
  ) => {
    return (
      <div className="w-full">
        {label && (
          <label className="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-300">
            {label}
          </label>
        )}
        <div className="relative">
          {leftElement && (
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
              {leftElement}
            </div>
          )}
          <input
            type={type}
            className={cn(
              'block w-full rounded-md border border-gray-300 bg-white px-3 py-2 shadow-sm transition-colors',
              'placeholder:text-gray-400',
              'focus:border-primary-500 focus:ring-primary-500 focus:outline-none focus:ring-1',
              'disabled:cursor-not-allowed disabled:bg-gray-50 disabled:text-gray-500',
              'dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder:text-gray-400',
              'dark:focus:border-primary-500 dark:focus:ring-primary-500',
              error && 'border-error-600 focus:border-error-600 focus:ring-error-600',
              leftElement && 'pl-10',
              rightElement && 'pr-10',
              className
            )}
            disabled={disabled || isLoading}
            ref={ref}
            {...props}
          />
          {rightElement && (
            <div className="absolute inset-y-0 right-0 flex items-center pr-3">
              {isLoading ? (
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-gray-300 border-t-gray-600" />
              ) : (
                rightElement
              )}
            </div>
          )}
        </div>
        {(error || hint) && (
          <p
            className={cn(
              'mt-1 text-sm',
              error ? 'text-error-600' : 'text-gray-500 dark:text-gray-400'
            )}
          >
            {error || hint}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';
