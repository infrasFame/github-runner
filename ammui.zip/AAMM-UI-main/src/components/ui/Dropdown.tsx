'use client';

import { Fragment } from 'react';
import { Menu, Transition } from '@headlessui/react';
import { motion } from 'framer-motion';
import { useAppContext } from '@/context/AppContext';

interface DropdownItem {
  label: string;
  value: string;
  icon?: React.ReactNode;
}

interface DropdownProps {
  trigger: React.ReactNode;
  items: DropdownItem[];
  onChange: (value: string) => void;
  placement?: 'top' | 'bottom' | 'left' | 'right';
}

export function Dropdown({ trigger, items, onChange, placement = 'bottom' }: DropdownProps) {
  const { state } = useAppContext();

  const getPlacementClasses = () => {
    switch (placement) {
      case 'top':
        return 'bottom-full mb-2';
      case 'bottom':
        return 'top-full mt-2';
      case 'left':
        return 'right-full mr-2';
      case 'right':
        return 'left-full ml-2';
      default:
        return 'top-full mt-2';
    }
  };

  return (
    <Menu as="div" className="relative">
      <Menu.Button
        as={motion.button}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className={`flex items-center rounded-full px-3 py-2 transition-colors ${
          state.isDarkMode
            ? 'bg-gray-800 text-gray-300 hover:bg-gray-700 hover:text-white'
            : 'bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-900'
        }`}
      >
        {trigger}
      </Menu.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-100"
        enterFrom="transform opacity-0 scale-95"
        enterTo="transform opacity-100 scale-100"
        leave="transition ease-in duration-75"
        leaveFrom="transform opacity-100 scale-100"
        leaveTo="transform opacity-0 scale-95"
      >
        <Menu.Items
          className={`absolute right-0 z-50 min-w-[200px] origin-top-right rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none ${
            state.isDarkMode
              ? 'border border-gray-700 bg-gray-800 p-1'
              : 'border border-gray-200 bg-white p-1'
          } ${getPlacementClasses()}`}
        >
          {items.map((item) => (
            <Menu.Item key={item.value}>
              {({ active }) => (
                <button
                  onClick={() => onChange(item.value)}
                  className={`flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm ${
                    state.isDarkMode
                      ? active
                        ? 'bg-gray-700 text-white'
                        : 'text-gray-300'
                      : active
                        ? 'bg-gray-100 text-gray-900'
                        : 'text-gray-600'
                  }`}
                >
                  {item.icon && (
                    <span className={state.isDarkMode ? 'text-gray-400' : 'text-gray-500'}>
                      {item.icon}
                    </span>
                  )}
                  {item.label}
                </button>
              )}
            </Menu.Item>
          ))}
        </Menu.Items>
      </Transition>
    </Menu>
  );
}
