'use client';

import { forwardRef } from 'react';
import { ButtonProps } from '@/types/components';
import { cn } from '@/utils/styles';

const sizeClasses = {
  xs: 'px-2 py-1 text-xs',
  sm: 'px-3 py-1.5 text-sm',
  md: 'px-4 py-2 text-base',
  lg: 'px-6 py-3 text-lg',
  xl: 'px-8 py-4 text-xl',
};

const variantClasses = {
  primary: 'bg-primary-600 text-white hover:bg-primary-700 active:bg-primary-800',
  secondary:
    'bg-gray-200 text-gray-900 hover:bg-gray-300 active:bg-gray-400 dark:bg-gray-700 dark:text-gray-100',
  tertiary: 'border border-primary-600 text-primary-600 hover:bg-primary-50 active:bg-primary-100',
  ghost:
    'text-gray-700 hover:bg-gray-100 active:bg-gray-200 dark:text-gray-300 dark:hover:bg-gray-800',
  link: 'text-primary-600 hover:underline p-0 height-auto',
};

const statusClasses = {
  idle: '',
  loading: 'opacity-80 cursor-wait',
  success: 'bg-success-600 text-white hover:bg-success-700',
  error: 'bg-error-600 text-white hover:bg-error-700',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant = 'primary',
      size = 'md',
      status = 'idle',
      isLoading = false,
      disabled,
      leftIcon,
      rightIcon,
      children,
      ...props
    },
    ref
  ) => {
    const currentStatus = isLoading ? 'loading' : status;

    return (
      <button
        ref={ref}
        className={cn(
          'focus:ring-primary-500 inline-flex items-center justify-center rounded-md font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 dark:focus:ring-offset-gray-900',
          sizeClasses[size],
          variantClasses[variant],
          statusClasses[currentStatus],
          className
        )}
        disabled={disabled || isLoading}
        {...props}
      >
        {isLoading ? (
          <span className="mr-2 inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
        ) : (
          leftIcon && <span className="mr-2">{leftIcon}</span>
        )}
        {children}
        {rightIcon && !isLoading && <span className="ml-2">{rightIcon}</span>}
      </button>
    );
  }
);

Button.displayName = 'Button';
