'use client';

import { ProgressProps } from '@/types/components';
import { cn } from '@/utils/styles';

const sizeClasses = {
  xs: { height: 'h-1.5', text: 'text-xs' },
  sm: { height: 'h-2', text: 'text-sm' },
  md: { height: 'h-3', text: 'text-base' },
  lg: { height: 'h-4', text: 'text-lg' },
  xl: { height: 'h-5', text: 'text-xl' },
};

const LineProgress = ({ value, max = 100, size = 'md', showLabel, className }: ProgressProps) => {
  const percentage = Math.round((value / max) * 100);

  return (
    <div className={cn('w-full', className)}>
      <div className="relative">
        <div
          className={cn(
            'w-full overflow-hidden rounded-full bg-gray-900/90 dark:bg-gray-950',
            sizeClasses[size].height
          )}
        >
          <div
            className="rounded-full bg-blue-500/80 transition-all duration-300 dark:bg-blue-500/60"
            style={{ width: `${percentage}%` }}
          />
        </div>
        {showLabel && (
          <div
            className={cn(
              'absolute -top-6 right-0 font-medium text-gray-900 dark:text-white',
              sizeClasses[size].text
            )}
          >
            {percentage}%
          </div>
        )}
      </div>
    </div>
  );
};

const CircleProgress = ({ value, max = 100, size = 'md', showLabel, className }: ProgressProps) => {
  const percentage = Math.round((value / max) * 100);
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;

  const sizeMap = {
    xs: 80,
    sm: 100,
    md: 120,
    lg: 140,
    xl: 160,
  };

  return (
    <div className={cn('relative inline-flex', className)}>
      <svg
        className="-rotate-90 transform"
        width={sizeMap[size]}
        height={sizeMap[size]}
        viewBox="0 0 100 100"
      >
        <circle
          className="text-gray-200 dark:text-gray-700"
          strokeWidth="8"
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx="50"
          cy="50"
        />
        <circle
          className="text-primary-600 transition-all duration-300"
          strokeWidth="8"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx="50"
          cy="50"
        />
      </svg>
      {showLabel && (
        <div
          className={cn(
            'absolute inset-0 flex items-center justify-center font-medium text-gray-900 dark:text-white',
            sizeClasses[size].text
          )}
        >
          {percentage}%
        </div>
      )}
    </div>
  );
};

export function Progress({ variant = 'line', ...props }: ProgressProps) {
  if (variant === 'circle') {
    return <CircleProgress {...props} />;
  }
  return <LineProgress {...props} />;
}
