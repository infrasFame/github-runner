'use client';

import { useState, Fragment } from 'react';
import { motion } from 'framer-motion';
import { Dialog, Transition } from '@headlessui/react';
import { ChevronDownIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import { Token } from '@/types/common';
import { Input } from '@/components/ui/Input';

const POPULAR_TOKENS: Token[] = [
  {
    address: '0x...',
    symbol: 'ETH',
    name: 'Ethereum',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/279/small/ethereum.png',
  },
  {
    address: '0x...',
    symbol: 'WBTC',
    name: 'Wrapped Bitcoin',
    decimals: 8,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/7598/small/wrapped_bitcoin_wbtc.png',
  },
  {
    address: '0x...',
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 6,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/6319/small/USD_Coin_icon.png',
  },
  {
    address: '0x...',
    symbol: 'USDT',
    name: 'Tether USD',
    decimals: 6,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/325/small/Tether.png',
  },
  {
    address: '0x...',
    symbol: 'DAI',
    name: 'Dai Stablecoin',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/9956/small/4943.png',
  },
  {
    address: '0x...',
    symbol: 'MATIC',
    name: 'Polygon',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/4713/small/matic-token-icon.png',
  },
  {
    address: '0x...',
    symbol: 'LINK',
    name: 'Chainlink',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/877/small/chainlink-new-logo.png',
  },
  {
    address: '0x...',
    symbol: 'UNI',
    name: 'Uniswap',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/12504/small/uniswap-uni.png',
  },
  {
    address: '0x...',
    symbol: 'AAVE',
    name: 'Aave',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/12645/small/AAVE.png',
  },
  {
    address: '0x...',
    symbol: 'ARB',
    name: 'Arbitrum',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/16547/small/photo_2023-03-29_21.47.00.jpeg',
  },
  {
    address: '0x...',
    symbol: 'OP',
    name: 'Optimism',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/25244/small/Optimism.png',
  },
  {
    address: '0x...',
    symbol: 'SOL',
    name: 'Solana',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/4128/small/solana.png',
  },
  {
    address: '0x...',
    symbol: 'AVAX',
    name: 'Avalanche',
    decimals: 18,
    chainId: 1,
    logoURI:
      'https://assets.coingecko.com/coins/images/12559/small/Avalanche_Circle_RedWhite_Trans.png',
  },
  {
    address: '0x...',
    symbol: 'DOGE',
    name: 'Dogecoin',
    decimals: 8,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/5/small/dogecoin.png',
  },
  {
    address: '0x...',
    symbol: 'SHIB',
    name: 'Shiba Inu',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/11939/small/shiba.png',
  },
];

interface TokenSelectProps {
  selectedToken: Token;
  onSelect: (token: Token) => void;
  otherToken?: Token;
}

export function TokenSelect({ selectedToken, onSelect, otherToken }: TokenSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTokens = POPULAR_TOKENS.filter(
    (token) =>
      token.address !== otherToken?.address &&
      (token.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
        token.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => setIsOpen(true)}
        className="flex items-center space-x-2 rounded-full bg-white/10 px-3 py-1.5 transition-colors hover:bg-white/20 dark:bg-gray-800/50 dark:hover:bg-gray-800/80"
      >
        <img
          src={selectedToken.logoURI}
          alt={selectedToken.symbol}
          className="h-5 w-5 rounded-full"
        />
        <span className="font-medium text-gray-900 dark:text-gray-100">{selectedToken.symbol}</span>
        <ChevronDownIcon className="h-4 w-4 text-gray-600 dark:text-gray-400" />
      </motion.button>

      <Transition show={isOpen} as={Fragment}>
        <Dialog onClose={() => setIsOpen(false)} className="relative z-50">
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-gray-900/50 backdrop-blur-sm dark:bg-black/50" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <Transition.Child
                as={Fragment}
                enter="ease-out duration-300"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-200"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <Dialog.Panel className="w-full max-w-md overflow-hidden rounded-2xl bg-white/80 p-6 shadow-xl backdrop-blur-sm dark:bg-gray-900/80">
                  <Dialog.Title className="text-lg font-medium text-gray-900 dark:text-white">
                    Select Token
                  </Dialog.Title>
                  <div className="mt-4">
                    <Input
                      type="text"
                      placeholder="Search by name or symbol"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      leftElement={<MagnifyingGlassIcon className="h-4 w-4 text-gray-400" />}
                      className="bg-white/50 dark:bg-gray-800/50"
                    />
                  </div>
                  <div className="mt-4 max-h-[400px] space-y-2 overflow-y-auto">
                    <div className="text-sm font-medium text-gray-500 dark:text-gray-400">
                      Popular Tokens
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {filteredTokens.map((token) => (
                        <motion.button
                          key={token.address}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => {
                            onSelect(token);
                            setIsOpen(false);
                          }}
                          className={`flex items-center space-x-2 rounded-lg p-3 text-left transition-colors ${
                            selectedToken.address === token.address
                              ? 'bg-primary-500/10 text-primary-500 dark:bg-primary-500/20'
                              : 'hover:bg-gray-100 dark:hover:bg-gray-800/50'
                          }`}
                        >
                          <img
                            src={token.logoURI}
                            alt={token.symbol}
                            className="h-8 w-8 rounded-full"
                          />
                          <div>
                            <div className="font-medium text-gray-900 dark:text-white">
                              {token.symbol}
                            </div>
                            <div className="text-xs text-gray-500 dark:text-gray-400">
                              {token.name}
                            </div>
                          </div>
                        </motion.button>
                      ))}
                    </div>
                  </div>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>
    </>
  );
}
