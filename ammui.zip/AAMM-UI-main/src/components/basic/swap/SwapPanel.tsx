'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowsUpDownIcon } from '@heroicons/react/24/outline';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Progress } from '@/components/ui/Progress';
import { Token } from '@/types/common';
import { TokenSelect } from './TokenSelect';
import { TransactionConfirmation } from './TransactionConfirmation';
import { TransactionStatus } from './TransactionStatus';
import { executeSwap } from '@/services/api/endpoints';
import { TransactionStatus as TxStatus } from '@/types/common';

const DEMO_TOKENS: Token[] = [
  {
    address: '0x...',
    symbol: 'ETH',
    name: 'Ethereum',
    decimals: 18,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/279/small/ethereum.png',
  },
  {
    address: '0x...',
    symbol: 'USDC',
    name: 'USD Coin',
    decimals: 6,
    chainId: 1,
    logoURI: 'https://assets.coingecko.com/coins/images/6319/small/USD_Coin_icon.png',
  },
];

const containerVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
      ease: 'easeOut',
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.3 },
  },
};

export function SwapPanel() {
  const [fromAmount, setFromAmount] = useState('');
  const [toAmount, setToAmount] = useState('');
  const [fromToken, setFromToken] = useState(DEMO_TOKENS[0]);
  const [toToken, setToToken] = useState(DEMO_TOKENS[1]);
  const [isLoading, setIsLoading] = useState(false);
  const [batchProgress, setBatchProgress] = useState(0);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [transaction, setTransaction] = useState<TxStatus | null>(null);

  // Simulate batch progress
  useEffect(() => {
    const interval = setInterval(() => {
      setBatchProgress((prev) => (prev >= 100 ? 0 : prev + 10));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSwapTokens = () => {
    setFromToken(toToken);
    setToToken(fromToken);
    setFromAmount(toAmount);
    setToAmount(fromAmount);
  };

  const handleSwapClick = () => {
    setShowConfirmation(true);
  };

  const handleConfirmSwap = async () => {
    try {
      setIsLoading(true);

      // Start transaction
      setTransaction({
        status: 'pending',
        hash: '',
        timestamp: Date.now(),
      });

      // Execute swap
      const result = await executeSwap(
        {
          inputToken: fromToken,
          outputToken: toToken,
          path: [fromToken, toToken],
          priceImpact: '0.1',
          executionPrice: '1',
          minimumReceived: toAmount,
          maximumSent: fromAmount,
        },
        '0x...' // Replace with actual user address
      );

      // Update transaction status
      setTransaction({
        status: 'success',
        hash: result.hash,
        timestamp: Date.now(),
      });

      // Reset form
      setFromAmount('');
      setToAmount('');
      setShowConfirmation(false);
    } catch (error) {
      setTransaction({
        status: 'failed',
        hash: '',
        timestamp: Date.now(),
        errorMessage: error instanceof Error ? error.message : 'Transaction failed',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <motion.div
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className="mx-auto w-full max-w-lg px-4 sm:px-0"
      >
        <Card className="w-full max-w-sm overflow-hidden bg-white/90 shadow-xl backdrop-blur-sm sm:max-w-lg dark:bg-gray-900/90">
          <div className="space-y-4 p-3 sm:space-y-6 sm:p-6">
            <motion.div
              variants={itemVariants}
              className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"
            >
              <h2 className="from-primary-500 to-primary-700 bg-gradient-to-r bg-clip-text text-lg font-semibold text-transparent sm:text-xl">
                Swap
              </h2>
              <motion.div
                variants={itemVariants}
                className="flex items-center space-x-2 rounded-full bg-white/10 px-3 py-1.5 sm:px-4 sm:py-2 dark:bg-gray-800/50"
              >
                <span className="text-xs text-gray-600 dark:text-gray-400">Current Batch:</span>
                <div className="flex items-center gap-2">
                  <Progress value={batchProgress} size="xs" className="w-24 sm:w-32" />
                  <span className="text-xs font-medium text-gray-600 dark:text-gray-400">
                    {batchProgress}%
                  </span>
                </div>
              </motion.div>
            </motion.div>

            {/* From Token */}
            <motion.div variants={itemVariants} className="space-y-1.5 sm:space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">From</label>
              <div className="relative">
                <Input
                  type="number"
                  value={fromAmount}
                  onChange={(e) => setFromAmount(e.target.value)}
                  placeholder="0.0"
                  className="bg-white/50 pr-16 backdrop-blur-sm transition-all duration-200 focus:bg-white sm:pr-20 dark:bg-gray-800/50 dark:focus:bg-gray-800"
                  rightElement={
                    <TokenSelect
                      selectedToken={fromToken}
                      onSelect={setFromToken}
                      otherToken={toToken}
                    />
                  }
                />
              </div>
            </motion.div>

            {/* Swap Button */}
            <motion.div variants={itemVariants} className="flex justify-center">
              <motion.button
                onClick={handleSwapTokens}
                whileHover={{ scale: 1.1, rotate: 180 }}
                whileTap={{ scale: 0.9 }}
                className="rounded-full bg-white/10 p-1.5 transition-colors hover:bg-white/20 sm:p-2 dark:bg-gray-800/50 dark:hover:bg-gray-800/80"
              >
                <ArrowsUpDownIcon className="h-4 w-4 text-gray-600 dark:text-gray-400" />
              </motion.button>
            </motion.div>

            {/* To Token */}
            <motion.div variants={itemVariants} className="space-y-1.5 sm:space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">To</label>
              <div className="relative">
                <Input
                  type="number"
                  value={toAmount}
                  onChange={(e) => setToAmount(e.target.value)}
                  placeholder="0.0"
                  className="bg-white/50 pr-16 backdrop-blur-sm transition-all duration-200 focus:bg-white sm:pr-20 dark:bg-gray-800/50 dark:focus:bg-gray-800"
                  rightElement={
                    <TokenSelect
                      selectedToken={toToken}
                      onSelect={setToToken}
                      otherToken={fromToken}
                    />
                  }
                />
              </div>
            </motion.div>

            {/* Price and Info */}
            <motion.div
              variants={itemVariants}
              className="space-y-2 rounded-xl bg-white/10 p-3 backdrop-blur-sm sm:p-4 dark:bg-gray-800/50"
            >
              <div className="flex items-center justify-between text-xs sm:text-sm">
                <span className="text-gray-600 dark:text-gray-400">Price Impact</span>
                <span className="font-medium text-gray-900 dark:text-white">{'< 0.1%'}</span>
              </div>
              <div className="flex items-center justify-between text-xs sm:text-sm">
                <span className="text-gray-600 dark:text-gray-400">Network Fee</span>
                <span className="font-medium text-gray-900 dark:text-white">~$2.50</span>
              </div>
              <div className="flex items-center justify-between text-xs sm:text-sm">
                <span className="text-gray-600 dark:text-gray-400">Route</span>
                <span className="text-primary-500 font-medium">
                  {fromToken.symbol} → {toToken.symbol}
                </span>
              </div>
            </motion.div>

            {/* Swap Button */}
            <motion.div variants={itemVariants}>
              <Button
                variant="primary"
                size="lg"
                isLoading={isLoading}
                className="from-primary-500 to-primary-700 hover:from-primary-600 hover:to-primary-800 w-full bg-gradient-to-r text-sm transition-all duration-300 sm:text-base"
                onClick={handleSwapClick}
                disabled={!fromAmount || !toAmount || isLoading}
              >
                Swap Tokens
              </Button>
            </motion.div>
          </div>
        </Card>

        {/* Transaction Confirmation Modal */}
        <TransactionConfirmation
          isOpen={showConfirmation}
          onClose={() => setShowConfirmation(false)}
          onConfirm={handleConfirmSwap}
          fromAmount={{ token: fromToken, amount: fromAmount }}
          toAmount={{ token: toToken, amount: toAmount }}
          priceImpact="0.1"
          networkFee="~$2.50"
          isLoading={isLoading}
        />

        {/* Transaction Status Notification */}
        {transaction && (
          <TransactionStatus
            status={transaction}
            onClose={() => setTransaction(null)}
            autoClose={transaction.status !== 'pending'}
          />
        )}
      </motion.div>
    </>
  );
}
