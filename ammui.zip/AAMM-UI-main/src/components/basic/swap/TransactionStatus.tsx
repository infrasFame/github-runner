'use client';

import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CheckCircleIcon,
  XCircleIcon,
  ArrowPathIcon,
  XMarkIcon,
} from '@heroicons/react/24/outline';
import { TransactionStatus as TxStatus } from '@/types/common';

interface TransactionStatusProps {
  status: TxStatus;
  onClose: () => void;
  autoClose?: boolean;
}

const statusConfig = {
  pending: {
    icon: ArrowPathIcon,
    title: 'Transaction Pending',
    color: 'text-blue-500',
    bg: 'bg-gray-900/95',
    ring: 'ring-1 ring-gray-800',
    iconBg: 'bg-blue-500/10',
  },
  success: {
    icon: CheckCircleIcon,
    title: 'Transaction Successful',
    color: 'text-green-500',
    bg: 'bg-gray-900/95',
    ring: 'ring-1 ring-gray-800',
    iconBg: 'bg-green-500/10',
  },
  failed: {
    icon: XCircleIcon,
    title: 'Transaction Failed',
    color: 'text-red-500',
    bg: 'bg-gray-900/95',
    ring: 'ring-1 ring-gray-800',
    iconBg: 'bg-red-500/10',
  },
};

export function TransactionStatus({ status, onClose, autoClose = true }: TransactionStatusProps) {
  const config = statusConfig[status.status];

  useEffect(() => {
    if (autoClose && (status.status === 'success' || status.status === 'failed')) {
      const timer = setTimeout(onClose, 5000);
      return () => clearTimeout(timer);
    }
  }, [status.status, autoClose, onClose]);

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={status.timestamp}
        initial={{ opacity: 0, y: -20, x: 20 }}
        animate={{ opacity: 1, y: 0, x: 0 }}
        exit={{ opacity: 0, x: 20 }}
        transition={{
          type: 'spring',
          stiffness: 500,
          damping: 30,
        }}
        className={`fixed right-2 top-2 z-[100] w-[calc(100%-1rem)] max-w-[20rem] overflow-hidden rounded-xl sm:right-4 sm:top-4 sm:max-w-md ${config.bg} ${config.ring} backdrop-blur-sm`}
      >
        <div className="p-3 sm:p-4">
          <div className="flex items-start justify-between gap-3 sm:gap-4">
            <div className="flex items-start gap-3 sm:gap-4">
              <div className={`mt-0.5 rounded-full p-1.5 sm:p-2 ${config.iconBg}`}>
                <config.icon
                  className={`h-4 w-4 sm:h-5 sm:w-5 ${config.color} ${
                    status.status === 'pending' ? 'animate-spin' : ''
                  }`}
                />
              </div>
              <div className="flex-1">
                <h3 className={`text-sm font-medium sm:text-base ${config.color}`}>
                  {config.title}
                </h3>
                <div className="mt-0.5 text-xs sm:mt-1 sm:text-sm">
                  {status.status === 'pending' && (
                    <div className="text-gray-400">Your transaction is being processed...</div>
                  )}
                  {status.status === 'success' && (
                    <div>
                      <div className="text-gray-400">Transaction has been confirmed</div>
                      <a
                        href={`https://etherscan.io/tx/${status.hash}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`mt-0.5 block text-xs sm:mt-1 sm:text-sm ${config.color} hover:opacity-80`}
                      >
                        View on Explorer ↗
                      </a>
                    </div>
                  )}
                  {status.status === 'failed' && (
                    <div className="text-red-400">{status.errorMessage || 'Failed to fetch'}</div>
                  )}
                </div>
              </div>
            </div>
            <button
              onClick={onClose}
              className="rounded-lg p-0.5 text-gray-500 hover:bg-gray-800 hover:text-gray-300 sm:p-1"
            >
              <XMarkIcon className="h-4 w-4 sm:h-5 sm:w-5" />
            </button>
          </div>
        </div>
        {autoClose && (status.status === 'success' || status.status === 'failed') && (
          <motion.div
            initial={{ scaleX: 1 }}
            animate={{ scaleX: 0 }}
            transition={{ duration: 5, ease: 'linear' }}
            className={`absolute inset-x-0 bottom-0 h-0.5 origin-left ${
              status.status === 'success' ? 'bg-green-500/20' : 'bg-red-500/20'
            }`}
          />
        )}
      </motion.div>
    </AnimatePresence>
  );
}
