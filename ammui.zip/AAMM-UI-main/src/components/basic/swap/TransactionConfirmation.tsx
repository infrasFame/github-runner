'use client';

import { Fragment } from 'react';
import { motion } from 'framer-motion';
import { Dialog, Transition } from '@headlessui/react';
import { ExclamationTriangleIcon, ArrowsRightLeftIcon } from '@heroicons/react/24/outline';
import { Token } from '@/types/common';
import { Button } from '@/components/ui/Button';

interface TokenAmount {
  token: Token;
  amount: string;
}

interface TransactionConfirmationProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  fromAmount: TokenAmount;
  toAmount: TokenAmount;
  priceImpact: string;
  networkFee: string;
  isLoading: boolean;
}

export function TransactionConfirmation({
  isOpen,
  onClose,
  onConfirm,
  fromAmount,
  toAmount,
  priceImpact,
  networkFee,
  isLoading,
}: TransactionConfirmationProps) {
  const isPriceImpactHigh = parseFloat(priceImpact) > 2;

  return (
    <Transition show={isOpen} as={Fragment}>
      <Dialog onClose={onClose} className="relative z-50">
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-gray-900/50 backdrop-blur-sm dark:bg-black/50" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel className="w-full max-w-sm overflow-hidden rounded-2xl bg-white/80 p-4 shadow-xl backdrop-blur-sm sm:max-w-md sm:p-6 dark:bg-gray-900/80">
                <Dialog.Title className="text-base font-medium text-gray-900 sm:text-lg dark:text-white">
                  Confirm Swap
                </Dialog.Title>

                {/* Transaction Details */}
                <div className="mt-4 space-y-4">
                  {/* Swap Summary */}
                  <div className="rounded-xl bg-white/50 p-3 sm:p-4 dark:bg-gray-800/50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <img
                          src={fromAmount.token.logoURI}
                          alt={fromAmount.token.symbol}
                          className="h-6 w-6 rounded-full sm:h-8 sm:w-8"
                        />
                        <div>
                          <div className="text-xs font-medium text-gray-900 sm:text-sm dark:text-white">
                            {fromAmount.amount} {fromAmount.token.symbol}
                          </div>
                        </div>
                      </div>
                      <ArrowsRightLeftIcon className="h-4 w-4 text-gray-400 sm:h-5 sm:w-5" />
                      <div className="flex items-center space-x-2">
                        <img
                          src={toAmount.token.logoURI}
                          alt={toAmount.token.symbol}
                          className="h-6 w-6 rounded-full sm:h-8 sm:w-8"
                        />
                        <div>
                          <div className="text-xs font-medium text-gray-900 sm:text-sm dark:text-white">
                            {toAmount.amount} {toAmount.token.symbol}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Price Impact Warning */}
                  {isPriceImpactHigh && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-warning-500/10 dark:bg-warning-500/20 rounded-lg p-3 sm:p-4"
                    >
                      <div className="flex items-center space-x-2">
                        <ExclamationTriangleIcon className="text-warning-500 h-4 w-4 sm:h-5 sm:w-5" />
                        <span className="text-warning-700 dark:text-warning-400 text-xs font-medium sm:text-sm">
                          High Price Impact: {priceImpact}%
                        </span>
                      </div>
                      <p className="text-warning-600 dark:text-warning-300 mt-1 text-xs">
                        This trade has a high price impact. You may receive significantly less
                        tokens than expected.
                      </p>
                    </motion.div>
                  )}

                  {/* Transaction Info */}
                  <div className="space-y-2 rounded-xl bg-white/50 p-3 sm:p-4 dark:bg-gray-800/50">
                    <div className="flex items-center justify-between text-xs sm:text-sm">
                      <span className="text-gray-600 dark:text-gray-400">Price Impact</span>
                      <span
                        className={`font-medium ${
                          isPriceImpactHigh
                            ? 'text-warning-500'
                            : 'font-medium text-gray-900 dark:text-white'
                        }`}
                      >
                        {priceImpact}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs sm:text-sm">
                      <span className="text-gray-600 dark:text-gray-400">Network Fee</span>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {networkFee}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs sm:text-sm">
                      <span className="text-gray-600 dark:text-gray-400">Route</span>
                      <span className="text-primary-500 font-medium">
                        {fromAmount.token.symbol} → {toAmount.token.symbol}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="mt-6 flex space-x-3">
                  <Button
                    variant="ghost"
                    size="lg"
                    className="flex-1 text-xs sm:text-sm"
                    onClick={onClose}
                    disabled={isLoading}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="primary"
                    size="lg"
                    className="flex-1 text-xs sm:text-sm"
                    onClick={onConfirm}
                    isLoading={isLoading}
                  >
                    Confirm Swap
                  </Button>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
}
