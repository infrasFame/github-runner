'use client';

import { useAppContext } from '@/context/AppContext';
import { motion } from 'framer-motion';
import { Dropdown } from '@/components/ui/Dropdown';
import {
  MoonIcon,
  SunIcon,
  ChevronRightIcon,
  Cog6ToothIcon,
  Bars3Icon,
} from '@heroicons/react/24/outline';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface BasicLayoutProps {
  children: React.ReactNode;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: -20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.3 },
  },
};

const mobileMenuVariants = {
  closed: {
    opacity: 0,
    y: -20,
    transition: {
      duration: 0.2,
    },
  },
  open: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.2,
    },
  },
};

export function BasicLayout({ children }: BasicLayoutProps) {
  const { state, dispatch } = useAppContext();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const router = useRouter();

  const dropdownItems = [
    {
      label: state.isDarkMode ? 'Light Mode' : 'Dark Mode',
      value: 'theme',
      icon: state.isDarkMode ? <SunIcon className="h-5 w-5" /> : <MoonIcon className="h-5 w-5" />,
    },
    {
      label: 'Switch to Advanced',
      value: 'mode',
      icon: <ChevronRightIcon className="h-5 w-5" />,
    },
  ];

  const handleDropdownChange = (value: string) => {
    if (value === 'theme') {
      dispatch({ type: 'SET_DARK_MODE', payload: !state.isDarkMode });
    } else if (value === 'mode') {
      router.push('/advanced');
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className={`flex min-h-screen flex-col ${
        state.isDarkMode
          ? 'bg-gradient-to-b from-gray-900 to-gray-950'
          : 'bg-gradient-to-b from-gray-50 to-white'
      }`}
    >
      {/* Header */}
      <motion.header
        variants={itemVariants}
        className={`sticky top-0 z-50 border-b backdrop-blur-lg ${
          state.isDarkMode ? 'border-gray-800/50 bg-gray-900/80' : 'border-gray-200/50 bg-white/80'
        }`}
      >
        <nav className="mx-auto flex max-w-7xl items-center justify-between p-4">
          {/* Left section */}
          <motion.h1
            whileHover={{ scale: 1.02 }}
            className="text-lg font-bold text-blue-500 sm:text-xl"
          >
            A2M2
          </motion.h1>

          {/* Desktop Navigation */}
          <div className="hidden items-center gap-3 sm:flex sm:gap-4">
            {/* Settings Dropdown */}
            <Dropdown
              trigger={
                <div className="flex items-center gap-2">
                  <Cog6ToothIcon
                    className={`h-5 w-5 ${state.isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}
                  />
                  <span
                    className={`text-sm ${state.isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}
                  >
                    Settings
                  </span>
                </div>
              }
              items={dropdownItems}
              onChange={handleDropdownChange}
              placement="bottom"
            />

            {/* Sync Wallet button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="rounded-full bg-blue-500 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-600"
            >
              Sync Wallet
            </motion.button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="rounded-lg p-2 sm:hidden"
          >
            <Bars3Icon
              className={`h-6 w-6 ${state.isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}
            />
          </button>
        </nav>

        {/* Mobile Menu */}
        <motion.div
          initial="closed"
          animate={isMobileMenuOpen ? 'open' : 'closed'}
          variants={mobileMenuVariants}
          className={`border-t sm:hidden ${
            state.isDarkMode ? 'border-gray-800/50' : 'border-gray-200/50'
          }`}
        >
          {isMobileMenuOpen && (
            <div className="space-y-2 p-4">
              {/* Mobile Settings */}
              {dropdownItems.map((item) => (
                <button
                  key={item.value}
                  onClick={() => handleDropdownChange(item.value)}
                  className={`flex w-full items-center gap-2 rounded-lg px-4 py-2 text-sm ${
                    state.isDarkMode
                      ? 'text-gray-300 hover:bg-gray-800'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <span className={state.isDarkMode ? 'text-gray-400' : 'text-gray-500'}>
                    {item.icon}
                  </span>
                  {item.label}
                </button>
              ))}

              {/* Mobile Sync Wallet button */}
              <motion.button
                whileTap={{ scale: 0.98 }}
                className="w-full rounded-lg bg-blue-500 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-600"
              >
                Sync Wallet
              </motion.button>
            </div>
          )}
        </motion.div>
      </motion.header>

      {/* Main content */}
      <motion.main
        variants={itemVariants}
        className="relative flex flex-1 items-center justify-center px-4 py-6 sm:py-12"
      >
        {/* Background gradient */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div
            className={`animate-gradient-xy h-[300px] w-[600px] rounded-full blur-3xl sm:h-[500px] sm:w-[800px] ${
              state.isDarkMode
                ? 'bg-gradient-to-r from-blue-500/10 via-transparent to-blue-700/10'
                : 'bg-gradient-to-r from-blue-500/5 via-transparent to-blue-700/5'
            }`}
          />
        </div>
        {children}
      </motion.main>

      {/* Footer */}
      <motion.footer
        variants={itemVariants}
        className={`border-t backdrop-blur-lg ${
          state.isDarkMode ? 'border-gray-800/50 bg-gray-900/80' : 'border-gray-200/50 bg-white/80'
        }`}
      >
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col items-center justify-between gap-4 px-4 py-4 text-center sm:flex-row sm:text-left">
            <p className={`text-sm ${state.isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              © 2024 A2M2. All rights reserved.
            </p>
            <div className="flex flex-wrap justify-center gap-4 sm:gap-6">
              <motion.a
                whileHover={{ scale: 1.02 }}
                href="#"
                className={`text-sm transition-colors ${
                  state.isDarkMode
                    ? 'text-gray-400 hover:text-white'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Documentation
              </motion.a>
              <motion.a
                whileHover={{ scale: 1.02 }}
                href="#"
                className={`text-sm transition-colors ${
                  state.isDarkMode
                    ? 'text-gray-400 hover:text-white'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Help Center
              </motion.a>
              <motion.a
                whileHover={{ scale: 1.02 }}
                href="#"
                className={`text-sm transition-colors ${
                  state.isDarkMode
                    ? 'text-gray-400 hover:text-white'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Terms
              </motion.a>
            </div>
          </div>
        </div>
      </motion.footer>
    </motion.div>
  );
}
