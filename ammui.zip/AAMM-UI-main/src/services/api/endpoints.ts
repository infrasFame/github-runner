import { Token, TokenAmount, SwapRoute, TransactionStatus } from '@/types/common';
import { apiRequest } from './client';
import { API_ENDPOINTS } from './config';

export async function getTokens(): Promise<Token[]> {
  return apiRequest<Token[]>(API_ENDPOINTS.TOKENS);
}

export async function getPrice(
  inputToken: Token,
  outputToken: Token,
  amount: string
): Promise<string> {
  const params = new URLSearchParams({
    inputToken: inputToken.address,
    outputToken: outputToken.address,
    amount,
  });
  return apiRequest<string>(`${API_ENDPOINTS.PRICE}?${params}`);
}

export async function getSwapQuote(
  inputAmount: TokenAmount,
  outputToken: Token
): Promise<SwapRoute> {
  return apiRequest<SwapRoute>(API_ENDPOINTS.QUOTE, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ inputAmount, outputToken }),
  });
}

export async function executeSwap(
  route: SwapRoute,
  userAddress: string
): Promise<TransactionStatus> {
  return apiRequest<TransactionStatus>(API_ENDPOINTS.SWAP, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ route, userAddress }),
  });
}

export async function getTransactionStatus(hash: string): Promise<TransactionStatus> {
  return apiRequest<TransactionStatus>(`${API_ENDPOINTS.TRANSACTION}/${hash}`);
}
