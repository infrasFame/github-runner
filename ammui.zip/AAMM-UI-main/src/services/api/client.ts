import { API_CONFIG, ApiError } from './config';

interface RequestOptions extends RequestInit {
  timeout?: number;
  retries?: number;
}

async function fetchWithTimeout(resource: string, options: RequestOptions = {}): Promise<Response> {
  const { timeout = API_CONFIG.TIMEOUT } = options;

  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);

  try {
    const response = await fetch(resource, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    throw error;
  }
}

async function handleResponse<T>(response: Response): Promise<T> {
  const contentType = response.headers.get('content-type');
  const isJson = contentType?.includes('application/json');
  const data = isJson ? await response.json() : await response.text();

  if (!response.ok) {
    throw new ApiError(data.message || 'An error occurred', response.status, data.code);
  }

  return data as T;
}

export async function apiRequest<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
  const { retries = API_CONFIG.RETRY_ATTEMPTS, ...fetchOptions } = options;
  const url = `${API_CONFIG.BASE_URL}${endpoint}`;

  let lastError: Error | null = null;
  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetchWithTimeout(url, fetchOptions);
      return await handleResponse<T>(response);
    } catch (error) {
      lastError = error as Error;
      if (i < retries - 1) {
        await new Promise((resolve) => setTimeout(resolve, API_CONFIG.RETRY_DELAY * (i + 1)));
      }
    }
  }

  throw lastError || new Error('Request failed');
}
