'use client';

import { WS_CONFIG, WS_EVENTS, WSEventType } from './config';

interface WSMessage<T = unknown> {
  type: WSEventType;
  data: T;
}

type MessageHandler<T = unknown> = (data: T) => void;

class WebSocketClient {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private pingInterval: NodeJS.Timeout | null = null;
  private handlers: Map<WSEventType, Set<MessageHandler>> = new Map();

  connect() {
    try {
      this.ws = new WebSocket(WS_CONFIG.URL);
      this.setupEventListeners();
    } catch (error) {
      console.error('WebSocket connection error:', error);
      this.handleReconnect();
    }
  }

  private setupEventListeners() {
    if (!this.ws) return;

    this.ws.onopen = () => {
      console.log('WebSocket connected');
      this.reconnectAttempts = 0;
      this.setupPing();
      this.emit(WS_EVENTS.CONNECTED, null);
    };

    this.ws.onclose = () => {
      console.log('WebSocket disconnected');
      this.cleanup();
      this.handleReconnect();
      this.emit(WS_EVENTS.DISCONNECTED, null);
    };

    this.ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      this.emit(WS_EVENTS.ERROR, error);
    };

    this.ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data) as WSMessage;
        this.emit(message.type, message.data);
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
  }

  private setupPing() {
    this.pingInterval = setInterval(() => {
      this.send({ type: WS_EVENTS.PING, data: null });
    }, WS_CONFIG.PING_INTERVAL);
  }

  private handleReconnect() {
    if (this.reconnectAttempts >= WS_CONFIG.MAX_RECONNECT_ATTEMPTS) {
      console.error('Max reconnection attempts reached');
      return;
    }

    this.reconnectAttempts++;
    setTimeout(() => {
      console.log('Attempting to reconnect...');
      this.connect();
    }, WS_CONFIG.RECONNECT_INTERVAL * this.reconnectAttempts);
  }

  private cleanup() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  subscribe<T = unknown>(event: WSEventType, handler: MessageHandler<T>) {
    if (!this.handlers.has(event)) {
      this.handlers.set(event, new Set());
    }
    this.handlers.get(event)?.add(handler as MessageHandler);
  }

  unsubscribe<T = unknown>(event: WSEventType, handler: MessageHandler<T>) {
    this.handlers.get(event)?.delete(handler as MessageHandler);
  }

  private emit<T = unknown>(event: WSEventType, data: T) {
    this.handlers.get(event)?.forEach((handler) => {
      (handler as MessageHandler<T>)(data);
    });
  }

  send(message: WSMessage) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    }
  }

  disconnect() {
    this.cleanup();
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}

// Create a singleton instance
export const wsClient = typeof window !== 'undefined' ? new WebSocketClient() : null;
