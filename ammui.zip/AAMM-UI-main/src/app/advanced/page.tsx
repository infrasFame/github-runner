'use client';

import { AdvancedLayout } from '@/components/advanced/layout/AdvancedLayout';
import { SwapPanel } from '@/components/basic/swap/SwapPanel';

export default function AdvancedSwapPage() {
  return (
    <AdvancedLayout>
      <SwapPanel />
    </AdvancedLayout>
  );
}
