'use client';

import { BasicLayout } from '@/components/basic/layout/BasicLayout';
import { SwapPanel } from '@/components/basic/swap/SwapPanel';

export default function BasicSwapPage() {
  return (
    <BasicLayout>
      <SwapPanel />
    </BasicLayout>
  );
}
