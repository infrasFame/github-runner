import type { Meta, StoryObj } from '@storybook/react';
import { UserIcon, CogIcon, ArrowRightOnRectangleIcon } from '@heroicons/react/24/outline';
import { Dropdown } from '../components/ui/Dropdown';

const meta = {
  title: 'Components/Dropdown',
  component: Dropdown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    placement: {
      control: 'select',
      options: ['top', 'bottom', 'left', 'right'],
    },
  },
} satisfies Meta<typeof Dropdown>;

export default meta;
type Story = StoryObj<typeof Dropdown>;

const items = [
  {
    label: 'Profile',
    value: 'profile',
    icon: <UserIcon className="h-5 w-5" />,
  },
  {
    label: 'Settings',
    value: 'settings',
    icon: <CogIcon className="h-5 w-5" />,
  },
  {
    label: 'Logout',
    value: 'logout',
    icon: <ArrowRightOnRectangleIcon className="h-5 w-5" />,
  },
];

export const Default: Story = {
  args: {
    trigger: 'Menu',
    items,
  },
};

export const WithValue: Story = {
  args: {
    trigger: 'Menu',
    items,
    value: 'settings',
  },
};

export const WithDisabledItem: Story = {
  args: {
    trigger: 'Menu',
    items: [...items.slice(0, 2), { ...items[2], disabled: true }],
  },
};

export const CustomPlacement: Story = {
  args: {
    trigger: 'Menu',
    items,
    placement: 'right',
  },
};
