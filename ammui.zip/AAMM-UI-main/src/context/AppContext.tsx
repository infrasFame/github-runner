'use client';

import { createContext, useContext, useReducer, ReactNode, useEffect } from 'react';
import { UIMode } from '@/types/common';

interface AppState {
  uiMode: UIMode;
  isDarkMode: boolean;
  isWalletConnected: boolean;
}

type AppAction =
  | { type: 'SET_UI_MODE'; payload: UIMode }
  | { type: 'SET_DARK_MODE'; payload: boolean }
  | { type: 'SET_WALLET_CONNECTED'; payload: boolean };

const initialState: AppState = {
  uiMode: 'basic',
  isDarkMode: false,
  isWalletConnected: false,
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_UI_MODE':
      return { ...state, uiMode: action.payload };
    case 'SET_DARK_MODE': {
      if (typeof window !== 'undefined') {
        if (action.payload) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
      return { ...state, isDarkMode: action.payload };
    }
    case 'SET_WALLET_CONNECTED':
      return { ...state, isWalletConnected: action.payload };
    default:
      return state;
  }
}

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Initialize dark mode based on system preference
  useEffect(() => {
    const isDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
    dispatch({ type: 'SET_DARK_MODE', payload: isDarkMode });
  }, []);

  return <AppContext.Provider value={{ state, dispatch }}>{children}</AppContext.Provider>;
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}
